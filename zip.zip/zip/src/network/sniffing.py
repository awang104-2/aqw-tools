from network.sending import send_dummy_packet, get_host, get_random_port
from multiprocessing import Process, Queue, Event
from debug.logger import Logger
from network.layers import Raw
from functools import partial
from scapy.all import sniff
from threading import Lock
from queue import Empty
import types


SENTINEL = b'STOP SNIFFING'


def stop_dummy(packet):
    return packet.haslayer(Raw) and packet[Raw].load == SENTINEL

def stop_event(packet, event):
    return event.is_set()


class SnifferRunningError(RuntimeError):

    def __init__(self, msg):
        super().__init__(msg)


class Sniff(Process):

    def __init__(self, bpf_filter, stop_filter, layers, queue, *, daemon=False, log=None):
        self.layers = layers
        self.packets = queue
        self.bpf_filter = bpf_filter
        self.packet_count = 0
        self.log = log
        self.stop_event = None
        self.stop_filter = stop_filter
        if not self.stop_filter:
            self.stop_event = Event()
            self.stop_filter = partial(stop_event, event=self.stop_event)
        super().__init__(name='Sniff Process', daemon=daemon)

    def run(self):
        logger = None
        if self.log:
            logger = Logger(self.log, 'packet sniffing process')
            logger.clear()
            logger.info('Started sniffing.')
        sniff(filter=self.bpf_filter, prn=lambda packet: self.log_packets(packet, logger), store=0, stop_filter=self.stop_filter)
        logger.info('Sniffing process stopped.')

    def log_packets(self, packet, logger):
        if self.layers:
            if any(packet.haslayer(layer) for layer in self.layers):
                self.packet_count += 1
                self.packets.put(packet)
                if logger:
                    logger.info(f'Received Packet-{self.packet_count}: {packet[Raw].load}')
        else:
            self.packet_count += 1
            self.packets.put(packet)
            if logger:
                logger.info(f'Received Packet-{self.packet_count}')


class Sniffer:

    def __init__(self, bpf_filter, stop_filter, layers: list | tuple = (), *, daemon=False, log=None):
        match stop_filter:
            case 'dummy':
                stop_filter = stop_dummy
            case 'event':
                stop_filter = None
        self._ip_host = get_host()[1]
        self._port = get_random_port()
        bpf_filter = f'({bpf_filter}) or (udp and dst host {self._ip_host} and dst port {self._port})'
        self.packets = Queue()
        self._process = Sniff(bpf_filter, stop_filter, layers, self.packets, daemon=daemon, log=log)
        self._lock = Lock()
        self.logger = Logger(log, 'sniffer')

    @property
    def filter(self):
        with self._lock:
            return self._process.bpf_filter

    @property
    def layers(self):
        with self._lock:
            return self._process.layers

    @property
    def daemon(self):
        with self._lock:
            return self._process.daemon

    @daemon.setter
    def daemon(self, daemon):
        with self._lock:
            self._process.daemon = daemon

    @property
    def running(self):
        with self._lock:
            return self._process.is_alive()

    def start(self):
        with self._lock:
            self._process.start()

    def stop(self, timeout=None):
        if self.running:
            with self._lock:
                self.logger.info('Attempting to stop Sniffer.')
                if self._process.stop_event:
                    self._process.stop_event.set()
                else:
                    send_dummy_packet(local=False, payload=SENTINEL, port=self._port, verbose=False)
                    self.logger.info(f'Sent dummy packet: {SENTINEL}')
                self._process.join(timeout)
                self.logger.info(f'Sniffer stopped.')

    def force_quit(self):
        with self._lock:
            try:
                self._process.terminate()
                self._process.join()
            except Exception as e:
                self.logger.error(f'Sniffer forced shutdown failed.')
                raise e

    def reset(self):
        self.logger.info('Attempting Sniffer reset.')
        if not self.running:
            with self._lock:
                layers =  self._process.layers
                bpf_filter, stop_filter = self._process.bpf_filter, self._process.stop_filter
                daemon, log = self._process.daemon, self._process.log
                self.packets = Queue()
                self._process = Sniff(bpf_filter, stop_filter, layers, self.packets, daemon=daemon, log=log)
            self.logger.info('Sniffer reset was successful.')
        else:
            self.logger.error('Sniffer reset failed: Sniffer was running.')

    def get(self, timeout=None):
        try:
            return self.packets.get(timeout=timeout)
        except Empty:
            return None


__all__ = [name for name, obj in globals().items() if not name.startswith('_') and not isinstance(obj, types.ModuleType)]
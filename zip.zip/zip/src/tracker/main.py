from gui import MainWindow
from game.updater import Updater
from game.character import Character
from debug.logger import get_file_names, get_unique_filename
from multiprocessing import active_children


def main():
    file_names = get_file_names()
    filename = 'log.txt'
    filename = get_unique_filename(filename, file_names)
    character = Character()
    updater = Updater(server='any', character=character, daemon=True, log=filename)
    main_window = MainWindow(updater, filename)
    main_window.run()
    updater.stop()
    updater.disconnect()


if __name__ == '__main__':
    main()
    children = active_children()
    for child in children:
        print(child.name)
        child.terminate()

